import React from 'react';
export default function Home(){
  return (
    <div>
      <h1>Gift Card Mall</h1>
      <p>Starter frontend. Click Buy to see UPI payment settings (fetched from backend).</p>
    </div>
  );
}
