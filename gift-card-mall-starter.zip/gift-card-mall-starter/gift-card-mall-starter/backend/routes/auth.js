const express = require('express');
const router = express.Router();
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const User = require('../models/User');

// Signup
router.post('/signup', async (req, res) => {
  const { username, password, whatsapp } = req.body;
  if(!username || !password) return res.status(400).json({ message: 'Missing fields' });
  try {
    const exists = await User.findOne({ username });
    if(exists) return res.status(400).json({ message: 'Username taken' });
    const salt = await bcrypt.genSalt(10);
    const hash = await bcrypt.hash(password, salt);
    const u = await User.create({ username, passwordHash: hash, whatsapp });
    const token = jwt.sign({ id: u._id }, process.env.JWT_SECRET);
    res.json({ token, user: { id: u._id, username: u.username, balance: u.balance }});
  } catch(err){
    res.status(500).json({ message: err.message });
  }
});

// Signin
router.post('/signin', async (req, res) => {
  const { username, password } = req.body;
  const u = await User.findOne({ username });
  if(!u) return res.status(400).json({ message: 'Invalid creds' });
  const ok = await require('bcryptjs').compare(password, u.passwordHash);
  if(!ok) return res.status(400).json({ message: 'Invalid creds' });
  const token = jwt.sign({ id: u._id }, process.env.JWT_SECRET);
  res.json({ token, user: { id: u._id, username: u.username, balance: u.balance, isAdmin: u.isAdmin }});
});

module.exports = router;
