const express = require('express');
const router = express.Router();
const PaymentSetting = require('../models/PaymentSetting');
const auth = require('../middleware/auth');
const admin = require('../middleware/admin');

// Get current settings
router.get('/', async (req, res) => {
  let s = await PaymentSetting.findOne();
  if(!s){
    s = await PaymentSetting.create({});
  }
  res.json(s);
});

// Admin update (multipart form for QR upload supported if you add multer)
router.post('/', auth, admin, async (req, res) => {
  const { upiId, note, qrImage } = req.body;
  let s = await PaymentSetting.findOne();
  if(!s) s = await PaymentSetting.create({});
  s.upiId = upiId ?? s.upiId;
  s.note = note ?? s.note;
  s.qrImage = qrImage ?? s.qrImage; // expect URL or base64 handler in future
  s.updatedAt = new Date();
  await s.save();
  res.json(s);
});

module.exports = router;
