import React from 'react';
import { BrowserRouter, Routes, Route, Link } from 'react-router-dom';
import Buy from './pages/Buy';
import Home from './pages/Home';
export default function App(){
  return (
    <BrowserRouter>
      <nav style={{padding:12, background:'#6B46C1', color:'white'}}>
        <Link to="/" style={{color:'white', marginRight:12}}>Home</Link>
        <Link to="/buy" style={{color:'white'}}>Buy</Link>
      </nav>
      <div style={{padding:20}}>
        <Routes>
          <Route path="/" element={<Home/>} />
          <Route path="/buy" element={<Buy/>} />
        </Routes>
      </div>
    </BrowserRouter>
  );
}
