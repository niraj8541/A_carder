const mongoose = require('mongoose');
const PaymentSettingSchema = new mongoose.Schema({
  upiId: { type: String, default: '' },
  qrImage: { type: String, default: '' }, // store URL/path
  note: { type: String, default: '' },
  updatedAt: { type: Date, default: Date.now }
});
module.exports = mongoose.model('PaymentSetting', PaymentSettingSchema);
