import React, {useEffect, useState} from 'react';
import API from '../api';
export default function Buy(){
  const [settings, setSettings] = useState(null);
  useEffect(()=> {
    API.get('/payment-settings').then(r => setSettings(r.data)).catch(err => console.error(err));
  }, []);
  return (
    <div>
      <h2>Make Payment</h2>
      {!settings && <p>Loading...</p>}
      {settings && (
        <div style={{border:'1px solid #eee', padding:16, borderRadius:8, maxWidth:480}}>
          {settings.qrImage ? <img src={settings.qrImage} alt="UPI QR" style={{maxWidth:'100%'}} /> : <div style={{padding:12, background:'#f7f7f7'}}>No QR uploaded</div>}
          <p><b>UPI ID:</b> {settings.upiId || 'Not set'}</p>
          {settings.note && <p><b>Note:</b> {settings.note}</p>}
          <hr/>
          <p>After paying, upload screenshot to submit payment (not implemented in starter)</p>
        </div>
      )}
    </div>
  );
}
